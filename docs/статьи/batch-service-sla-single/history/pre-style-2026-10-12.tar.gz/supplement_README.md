# Электронное приложение к переработанной статье

Версия 2026-10-12. Это воспроизводимый исследовательский пакет, а не
сертификат полной ошибки бесконечной очереди. Протокол и исходные наблюдения
сохранены без изменения; три отказа уточнения и несовпадения с точечными
имитационными интервалами не исключены из данных.

## Состав

- `most_queue/`, `examples/`, `tests/units/test_bulk_service_revision.py`:
  исходный код и независимые регрессионные проверки.
- `docs/research/bulk-sla-revision-*-2026.json`: четыре исходные панели,
  каждый шаг уточнения и все 264 независимых имитационных повторения.
- `docs/research/bulk-sla-revision-protocol-2026.md`: протокол, зафиксированный
  до экспериментов; отчёт об исправлениях находится рядом.
- `docs/статьи/batch-service-sla-single/`: LaTeX/PDF, редактируемый Word,
  рисунки, таблицы, производные результаты и скрипты сборки.
- `manifest.json`: SHA-256 каждого включённого файла; численные зависимости
  закреплены в `requirements-reproduction.txt`.

Чужие полные тексты, старые версии статьи, личный журнал и диссертация в
приложение не включены. Код библиотеки — под MIT; лицензия приложена.
CSL-стиль сохранён с собственными лицензионными метаданными.

## Воспроизведение вычислений

Ниже команды выполняются из корня распакованного архива. Исходные прогоны
использовали Python 3.12.3, NumPy 2.2.5, SciPy 1.13.0. Другие версии могут
давать отличия округления; побитное совпадение времени исполнения не ожидается.

```bash
python3.12 -m venv .venv
.venv/bin/pip install -r requirements-reproduction.txt
.venv/bin/pip install .
.venv/bin/pytest tests/units/test_bulk_service_revision.py -q
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m examples.bulk_sla_revision --panel patience --output-dir recomputed
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m examples.bulk_sla_revision --panel load --output-dir recomputed
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m examples.bulk_sla_revision --panel decision --output-dir recomputed
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m examples.bulk_sla_revision --panel inoue --output-dir recomputed
.venv/bin/python docs/статьи/batch-service-sla-single/verify_reproduction.py recomputed
```

Скрипт отказывается перезаписывать существующий JSON. Для нового повтора
выберите другое имя выходного каталога. Сверка проверяет все научные поля
каждого сценария, включая сырые имитационные повторы, отказы и критерии
уточнения. Исключены только длительности исполнения; версии и кодовые хеши
нового прогона записываются отдельно. В этой ревизии финальный код также
повторно проверен на всём протоколе; отчёт — `reproduction_verification.json`,
результаты повторного прогона — в `verification/recomputed/` рядом с ним.

Исходные JSON содержат хеши кода на момент первых прогонов. После них были
внесены форматирование, уточнения документации и валидации параметров,
исправление приведения целочисленного gamma и переносимый путь протокола,
добавлен `--output-dir`. Поэтому эти хеши не заменены хешами финального кода.
Текущие контрольные суммы находятся в `manifest.json`; соответствие численных
результатов подтверждается повторным прогоном, а не совпадением старых хешей.

## Документы

```bash
.venv/bin/python docs/статьи/batch-service-sla-single/build_revision.py
cd docs/статьи/batch-service-sla-single/latex
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

Нужны XeLaTeX, Biber, `biblatex-gost`, `polyglossia`, шрифт PT Serif;
для рисунков используется DejaVu Sans. Из корня архива Word собирается так:

```bash
uv run --no-project --with lxml --with pypandoc_binary python docs/статьи/batch-service-sla-single/build_word.py
```

Сначала нужно собрать LaTeX для номеров перекрёстных ссылок. Word содержит
нативные редактируемые формулы и таблицы; это не снимок страниц. Исходным
текстом служит `latex/article.tex`, а не отдельная вручную правимая Word-копия.
Редакторская правка должна начинаться с этого источника и повторной сборки.

Три источника (Medhi, Neuts, Banerjee) изучены лишь в пределах доступных
первичных метаданных/аннотаций, что отражено в локальных литературных
карточках автора. Исчерпывающий приоритет сочетания условий не заявлен.

"""
Simulation model of QS GI/G/n/r and GI/G/n with vacations
"""

from most_queue.random.utils.create import create_distribution
from most_queue.sim.base import QsSim
from most_queue.sim.utils.phase import QsPhase
from most_queue.sim.utils.servers import Server
from most_queue.structs import VacationResults


class VacationQueueingSystemSimulator(QsSim):
    """
    Simulation model of QS GI/G/n/r and GI/G/n
    """

    def __init__(
        self,
        num_of_channels: int,
        buffer: int | None = None,
        verbose: bool = True,
        buffer_type: str = "list",
        is_service_on_warm_up: bool = False,
        is_multiple_vacations: bool = False,
    ):  # pylint: disable=too-many-positional-arguments, too-many-arguments
        """
        Initialize the queueing system with GI/G/n/r or GI/G/n model.
        :param num_of_channels: int : number of channels in the system
        :param buffer: Optional(int, None) : maximum length of the queue, None if infinite
        :param verbose: bool : whether to print detailed information during simulation
        :param buffer_type: str : type of the buffer, "list" or "deque"
        :param is_service_on_warm_up: bool :
            if is True, jobs arrived in empty system will be served with warm_phase distribution
            if is False, jobs arrived in empty system will be send to queue,
                and warm_phase starts with warm_phase distribution
        :param is_multiple_vacations: bool :
            if True, the server takes another vacation (cold period) immediately
            when the queue is still empty at the end of a vacation — classic
            multiple-vacations discipline. If False (default), the server stays
            idle after the cold period ends with an empty queue (single vacation).
        """
        super().__init__(num_of_channels, buffer, verbose, buffer_type)

        self.warm_phase = QsPhase("WarmUp")
        self.cold_phase = QsPhase("Cold")
        self.cold_delay_phase = QsPhase("ColdDelay")

        self.warm_after_cold_starts = 0
        self.is_service_on_warm_up = is_service_on_warm_up
        self.is_multiple_vacations = is_multiple_vacations

    def set_warm(self, params, kendall_notation):
        """
        Set the type and parameters of the warm-up time distribution

        :param params: list : parameters for the warm-up time distribution
        :param kendall_notation: str : Kendall notation for the warm-up time distribution

        """
        if not self.is_set_server_params:
            raise ValueError("Server parameters are not set. Please call set_servers() first.")

        dist = create_distribution(params, kendall_notation, self.generator)
        self.warm_phase.set_dist(dist)

        if self.is_service_on_warm_up:
            self.servers = []
            for _i in range(self.n):
                server = Server(
                    self.server_params,
                    self.server_kendall_notation,
                    generator=self.generator,
                )
                server.set_warm(params, kendall_notation, self.generator)
                self.servers.append(server)
            self._servers_time_changed = True
            self._free_servers = set(range(self.n))

    def set_cold(self, params, kendall_notation):
        """
        Set the type and parameters of the cooling time distribution
        :param params: list : parameters for the cooling time distribution
        :param kendall_notation: str : Kendall notation for the cooling time distribution
        """
        dist = create_distribution(params, kendall_notation, self.generator)
        self.cold_phase.set_dist(dist)

    def set_cold_delay(self, params, kendall_notation):
        """
        Set the type and parameters of the cooling start delay time distribution
        :param params: list : parameters for the cooling start delay time distribution
        :param kendall_notation: str : Kendall notation for
        the cooling start delay time distribution
        """

        if not self.cold_phase.is_set:
            raise ValueError("You must first set the cooling time. Use the set_cold() method.")

        dist = create_distribution(params, kendall_notation, self.generator)
        self.cold_delay_phase.set_dist(dist)

    def _get_custom_events(self):
        """
        Get custom events (warm-up end, cold end, cold delay end).
        """
        events = {}
        if self.warm_phase.is_set and self.warm_phase.is_start:
            events["warm_up_end"] = self.warm_phase.end_time
        if self.cold_phase.is_set and self.cold_phase.is_start:
            events["cold_end"] = self.cold_phase.end_time
        if self.cold_delay_phase.is_set and self.cold_delay_phase.is_start:
            events["cold_delay_end"] = self.cold_delay_phase.end_time
        return events

    def _handle_custom_event(self, event_type: str):
        """
        Handle custom events for vacations (warm-up, cold, cold delay).
        """
        if event_type == "warm_up_end":
            self.on_end_warming()
        elif event_type == "cold_end":
            self.on_end_cold()
        elif event_type == "cold_delay_end":
            self.on_end_cold_delay()
        else:
            super()._handle_custom_event(event_type)

    def arrival(self, moment=None, ts=None):
        """
        Actions upon arrival of the job by the QS.
        """

        self.arrived += 1
        # Update state probabilities
        self._update_state_probs(self.ttek, self.arrival_time, self.in_sys)

        self.in_sys += 1
        self.ttek = self.arrival_time
        self.arrival_time = self.ttek + self.source.generate()

        if self.free_channels == 0:
            self.send_task_to_queue()

        else:  # there are free channels:

            if self.cold_phase.is_set:
                if self.cold_phase.is_start:
                    # Cooling is not finished yet. In queue
                    self.send_task_to_queue()
                    return

            if self.cold_delay_phase.is_set:
                if self.cold_delay_phase.is_start:
                    # The job was received before the end of the cooling start
                    # delay time
                    self.cold_delay_phase.is_start = False
                    self.cold_delay_phase.end_time = 1e16
                    self.cold_delay_phase.prob += self.ttek - self.cold_delay_phase.start_mom
                    self.send_task_to_channel()
                    return

            if self.warm_phase.is_set:
                # Warm-up set

                # Check warm-up. By this point the system is definitely not in cooling mode
                # and not in the cooling start delay state.
                # So either:
                # 1. In warm-up mode -> send the job to the queue
                # 2. It is empty and was turned off after cooling. Start warm-up
                # 3. Not empty and warmed up -> then send it for maintenance
                if self.warm_phase.is_start:
                    # 1. In warm-up mode -> send the job to the queue
                    self.send_task_to_queue()
                else:
                    if self.free_channels == self.n:
                        # to queue
                        if self.is_service_on_warm_up:
                            self.send_task_to_channel(is_warm_start=True)
                        else:
                            # 2. It is empty and was turned off after cooling.
                            # We start warm-up
                            self.warm_phase.start(self.ttek)
                            self.send_task_to_queue()
                    else:
                        # 3. Not empty and warmed up -> then we send it for
                        # servicing
                        self.send_task_to_channel()

            else:
                # No warm-up. Send a job to the service channel
                self.send_task_to_channel()

    def serving(self, c, is_network=False):
        """
        Actions upon receipt of a service job with - channel number
        """
        time_to_end = self.servers[c].time_to_end_service
        end_ts = self.servers[c].end_service()
        self._free_servers.add(c)  # Server is now free
        self._mark_servers_time_changed()

        # Update state probabilities
        self._update_state_probs(self.ttek, time_to_end, self.in_sys)

        self.ttek = time_to_end
        self.served += 1
        self.total += 1
        self.free_channels += 1
        self.refresh_v_stat(self.ttek - end_ts.arr_time)

        self.in_sys -= 1

        # BUSY PERIOD
        if self.queue.size() == 0 and self.free_channels == 1:
            if self.in_sys == self.n - 1:
                # busy period ends
                self.busy_moments += 1
                self.refresh_busy_stat(self.ttek - self.start_busy)

        # COLD
        if self.cold_phase.is_set:
            if self.queue.size() == 0 and self.free_channels == self.n:
                # The system has become empty.
                # 1. If a delay in the start of cooling is set, we play the time of its end
                # 2. If not, we start cooling
                if self.cold_delay_phase.is_set:
                    self.cold_delay_phase.start(self.ttek)
                else:
                    self.cold_phase.start(self.ttek)

        if self.queue.size() != 0:
            self.send_head_of_queue_to_channel(c)

    def on_end_warming(self):
        """
        Job that has to be done after WarmUp Period Ends
        """
        # Update state probabilities
        self._update_state_probs(self.ttek, self.warm_phase.end_time, self.in_sys)

        self.ttek = self.warm_phase.end_time

        self.warm_phase.end(self.ttek)

        # Send n jobs from the queue to the channels
        for i in range(self.n):
            if self.queue.size() != 0:
                self.send_head_of_queue_to_channel(i)

    def on_end_cold(self):
        """
        Job that has to be done after Cold Period Ends
        """
        # Update state probabilities
        self._update_state_probs(self.ttek, self.cold_phase.end_time, self.in_sys)

        self.ttek = self.cold_phase.end_time

        self.cold_phase.end(self.ttek)

        if self.is_multiple_vacations and self.queue.size() == 0:
            # Multiple vacations: queue is still empty, take another vacation
            self.cold_phase.start(self.ttek)
            return

        if self.warm_phase.is_set:
            if self.queue.size() != 0:
                # We start warming up only if there are jobs accumulated in the
                # queue.
                self.warm_after_cold_starts += 1
                self.warm_phase.start(self.ttek)

        else:
            # Send n jobs from the queue to the channels
            for i in range(self.n):
                if self.queue.size() != 0:
                    self.send_head_of_queue_to_channel(i)

    def on_end_cold_delay(self):
        """
        Job that has to be done after Cold Delay Period Ends
        """
        # Update state probabilities
        self._update_state_probs(self.ttek, self.cold_delay_phase.end_time, self.in_sys)

        self.ttek = self.cold_delay_phase.end_time

        self.cold_delay_phase.end(self.ttek)

        # Start the cooling process
        self.cold_phase.start(self.ttek)

    # run_one_step is now inherited from base class and uses event-based approach
    # Custom events are handled via _get_custom_events() and _handle_custom_event()

    def run(self, total_served) -> VacationResults:
        """
        Run simulation process
        """
        results = super().run(total_served=total_served)

        return VacationResults(
            v=results.v,
            w=results.w,
            p=results.p,
            utilization=results.utilization,
            duration=results.duration,
            warmup_prob=self.get_warmup_prob(),
            cold_prob=self.get_cold_prob(),
        )

    def get_warmup_prob(self):
        """
        Returns probability of the system being in the warm-up phase
        """
        return self.warm_phase.get_prob(self.ttek)

    def get_cold_prob(self):
        """
        Returns probability of the system being in the cold phase
        """
        return self.cold_phase.get_prob(self.ttek)

    def get_cold_delay_prob(self):
        """
        Returns probability of the system being in the delay cold phase
        """
        return self.cold_delay_phase.get_prob(self.ttek)


class NPolicyQueueSim(VacationQueueingSystemSimulator):
    """
    Simulation of a queue under N-policy: the server switches off when the
    system empties and resumes service only when N jobs have accumulated,
    then serves exhaustively.

    The switched-off state is modeled as an infinitely long cold phase that is
    terminated as soon as the number of jobs in the system reaches N.
    """

    _INFINITE_COLD = 1e100

    def __init__(self, num_of_channels: int, big_n: int, **kwargs):
        """
        :param num_of_channels: int : number of channels in the system
        :param big_n: int : policy threshold N (server resumes at N jobs)
        """
        super().__init__(num_of_channels, **kwargs)
        if big_n < 1:
            raise ValueError(f"N must be >= 1, got {big_n}")
        self.big_n = big_n
        self.set_cold(self._INFINITE_COLD, "D")
        # the system starts empty with the server switched off
        self.cold_phase.start(0)

    def arrival(self, moment=None, ts=None):
        """
        Standard arrival; additionally ends the switched-off (cold) state
        as soon as N jobs have accumulated.
        """
        super().arrival(moment, ts)
        if self.cold_phase.is_start and self.in_sys >= self.big_n:
            self.cold_phase.end_time = self.ttek
            self.on_end_cold()
